# csci566-data2 > 2022-05-08 12:39am
https://universe.roboflow.com/566pub-wrd60/csci566-data2

Provided by a Roboflow user
License: CC BY 4.0


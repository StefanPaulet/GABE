# Csgo-2 > 2023-10-08 2:45am
https://universe.roboflow.com/hieu-minh-yx9ep/csgo-2-hfa81

Provided by a Roboflow user
License: CC BY 4.0

